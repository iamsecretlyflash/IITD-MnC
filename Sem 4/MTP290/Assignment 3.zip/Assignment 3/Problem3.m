%Simpson's 1/3 rule
a = 0;b = 2;n =4;
lst = linspace(a,b,n+1);

ans13 = 0;

for i = 1:n
    %iterating over intervals to calculate the value of the integral
    ans13 = ans13 + simpsons_one_third_interval(lst(i),lst(i+1));
end
fprintf("\nValue of the integral [exp(x)/(1+x) in 0 to 2] using composite simpson's 1/3 method = %f\n",ans13)

%using in built intergal
syms x
ff = exp(x)/(1+x);
fprintf("\nValue of the integral [exp(x)/(1+x) in 0 to 2] using in-built integral calculator = %f\n",vpa(int(ff,a,b)))

%using 3/8 method
fprintf("\nIterating over segment length to get relative error under the tolerance")
n = 0; tol = 1e-6;
temp_tol = 100;
temp_ans = 10000;
a = 0;b = pi/2;
iter = 0;
while temp_tol >tol
    n = n+1;
    iter = iter +1;
    lst = linspace(a,b,n+1);
    res = simpson_three_eight(lst,n);
    temp_tol = (abs(res-temp_ans))/res;
    temp_ans = res;
end
fprintf("\nValue of the intergal of [sin(x) in 0 to pi/2] using simpson's 3/8 method = %f\nNumber of iterations = %d\nInterval size = %d\n",temp_ans,iter,n)

function val = simpsons_one_third_interval(l,r)
    % subroutine to calculate the value of the integral in a smaller
    % interval
    mid = (l+r)/2;
    val = ((r-l)/6)*(f(l) + 4*f(mid) + f(r));
end


function val = simpson_three_eight(lst,n)
    %function to calvulate the value of the integral in the given range
    %by splitting the range into n sub-ranges
    val = 0;
    for i = 1:n
        val = val + simpson_three_eight_method(lst(i),lst(i+1));
    end
    
end

function val = simpson_three_eight_method(l,r)
    % subroutine to calculate the value of the integral in a smaller
    % interval
    mid1 = l + (r-l)/3;
    mid2 = l + 2*(r-l)/3;

    val = ((r-l)/8)*(g(l) + 3*g(mid1) + 3*g(mid2) + g(r));
end

function val = f(x)
    val = exp(x)/(1+x);
end

function val = g(x)
    val = sin(x);
end

