
a = 0; b =10 ; tol = 1e-6;

anss = 100;
temp_tol = 100;
n = 0;
iter = 0;
while temp_tol >tol
    iter = iter +1;
    n = n + 1;
    res = 0;
    lst = linspace(a,b,n+1);
    for i = 1:n
            res = res+((lst(i+1)-lst(i))/2)*(f(lst(i))+f(lst(i+1)));
    end

    temp_tol = abs((anss-res)/res);
    anss = res;
end

syms x
g = sin(x)/x;
fprintf("\nValue of the intergal using Trapezoidal Rule = %f\nNumber of iterations = %d\nInterval size = %d\n",anss,iter,n)
fprintf("\nValue of the intergal using in-built integral calculator = %f\n",vpa(int(g,0,10)))


function val = f(x)
    if x == 0
        val = 1;
    else
        val = sin(x)/x;
    end
end

