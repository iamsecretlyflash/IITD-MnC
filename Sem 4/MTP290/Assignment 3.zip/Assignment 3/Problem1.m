%Trapezoidal Rule

%I = (b-a)(f(a) + f(b))/2
%actual answer = 2*arctan(4) = 2.6516
b = 4; a = -4;

fprintf("\nSUB-PART (a)\n")
%Calculating area by taking a as -4 and b as 4 
I = ((b-a)/2)*(f(b)+f(a));
fprintf("\nArea calculated by aplying trapezoidal rule in the interval [-4,4] : %f",I)

% Calculating area by taking a as 0 and b as 4 and multiplying by 2(
%due to symmetry)
%NOT A PART OF THE PROBLEM STATEMENT BUT INTERESTING TO LOOK AT
I = 2*(b-(0))*(1/2)*(f(0)+f(b));
fprintf("\nArea calculated by aplying trapezoidal rule in the interval [-4,0] and multipyling by 2 : %f\n",I)



%Simpson's 1/3 Rule
fprintf("\nSUB-PART (b)\n")
x_mid= 0;
I = simpsons_one_third_interval(a,b);
fprintf("\nArea calculated by aplying simpson's 1/3 rule once in the interval [-4,4] : %f\n",I)

fprintf("\nSUB-PART (c)\n")
fprintf("\nCOMPOSITE TRAPEZOIDAL RULE")
%Composite Trapezoid
%2.65114192685511
format longg
n = 10;
res = 0;
start = a;
lst = linspace(a,b,n+1);
for i = 1:n
    res = res+(lst(i+1)-lst(i))*(1/2)*(f(lst(i))+f(lst(i+1)));
    start  = i;
end
fprintf("\nArea calculated by aplying Trapezoidal rule 10 times in the interval [-4,4] : %f\n",res)

fprintf("\nCOMPOSITE SIMPSON'S 1/3 RULE")
%Composite Simpson's 1/3 Rule 2.69528592236713
n = 10;
lst = linspace(a,b,n+1);
res = 0;
for i = 1:n
    res = res + simpsons_one_third_interval(lst(i),lst(i+1));
end
fprintf("\nArea calculated by aplying Simpson's 1/3 rule 10 times in the interval [-4,4] : %f\n",res)

function val = simpsons_one_third_interval(l,r)
    % subroutine to calculate the value of the integral in a smaller
    % interval
    mid = (l+r)/2;
    val = ((r-l)/6)*(f(l) + 4*f(mid) + f(r));
end

function val = f(x)
    val = 1/(1+x^2);
end

